#ifndef key
#define ley

void loadKey(unsigned char * key, unsigned int from);

void saveKey(unsigned char * key, unsigned int from);

#endif
